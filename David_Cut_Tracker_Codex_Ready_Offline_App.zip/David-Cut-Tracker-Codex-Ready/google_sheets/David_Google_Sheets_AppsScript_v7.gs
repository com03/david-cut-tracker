function onOpen() {
  SpreadsheetApp.getUi()
    .createMenu('David Tracker')
    .addItem('Log Quick Add to Today', 'logQuickAddToToday')
    .addItem('Log Meal by Text', 'logMealByText')
    .addItem('Mark Lifted Today', 'markLiftedToday')
    .addItem('Show Cheat Status', 'showCheatStatus')
    .addToUi();
}

function getTodayRow_(sheet) {
  const today = new Date();
  today.setHours(0,0,0,0);
  const dates = sheet.getRange('A2:A731').getValues();
  for (let i = 0; i < dates.length; i++) {
    const d = dates[i][0];
    if (d instanceof Date) {
      d.setHours(0,0,0,0);
      if (d.getTime() === today.getTime()) return i + 2;
    }
  }
  throw new Error('Today was not found in Daily_Log. Check your dates.');
}

function logQuickAddToToday() {
  const ss = SpreadsheetApp.getActive();
  const log = ss.getSheetByName('Daily_Log');
  const quick = ss.getSheetByName('Quick_Add');
  const row = getTodayRow_(log);
  const meals = quick.getRange('B4:B7').getValues().flat();
  log.getRange(row, 4, 1, 4).setValues([meals]);
  SpreadsheetApp.getUi().alert('Quick Add meals copied to today.');
}

function logMealByText() {
  const ui = SpreadsheetApp.getUi();
  const result = ui.prompt('Log meal by text', 'Type a meal name or alias from the Meals tab, like buffalo wrap or chicken rice.', ui.ButtonSet.OK_CANCEL);
  if (result.getSelectedButton() !== ui.Button.OK) return;
  const text = result.getResponseText().toLowerCase().trim();
  const ss = SpreadsheetApp.getActive();
  const mealsSheet = ss.getSheetByName('Meals');
  const log = ss.getSheetByName('Daily_Log');
  const data = mealsSheet.getRange('A2:K200').getValues();
  let match = null;
  for (const row of data) {
    const name = String(row[0] || '').toLowerCase();
    const alias = String(row[10] || '').toLowerCase();
    if (name && (name.includes(text) || alias.includes(text) || text.includes(name))) {
      match = row[0];
      break;
    }
  }
  if (!match) {
    ui.alert('No meal found. Add it to Meals first or use Custom Cals/Protein.');
    return;
  }
  const todayRow = getTodayRow_(log);
  const mealSlots = log.getRange(todayRow, 4, 1, 4).getValues()[0];
  const slotIndex = mealSlots.findIndex(v => !v || v === 'Skip / None');
  if (slotIndex === -1) {
    ui.alert('All meal slots are filled today. Replace one manually or use Custom Cals.');
    return;
  }
  log.getRange(todayRow, 4 + slotIndex).setValue(match);
  ui.alert('Logged: ' + match);
}

function markLiftedToday() {
  const ss = SpreadsheetApp.getActive();
  const log = ss.getSheetByName('Daily_Log');
  const row = getTodayRow_(log);
  log.getRange(row, 17).setValue('Yes');
  SpreadsheetApp.getUi().alert('Lifted marked Yes for today.');
}

function showCheatStatus() {
  const ss = SpreadsheetApp.getActive();
  const log = ss.getSheetByName('Daily_Log');
  const row = getTodayRow_(log);
  const status = log.getRange(row, 31).getDisplayValue();
  const allowed = log.getRange(row, 32).getDisplayValue();
  const eta = log.getRange(row, 33).getDisplayValue();
  SpreadsheetApp.getUi().alert('Cheat Status: ' + status + '\nAllowed extra calories: ' + allowed + '\nETA: ' + eta);
}
