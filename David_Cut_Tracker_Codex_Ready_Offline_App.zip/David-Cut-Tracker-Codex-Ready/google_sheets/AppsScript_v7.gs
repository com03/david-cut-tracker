/* Optional Apps Script backup for Google Sheets. Main workflow is the offline web app. Preserve no-tuna rule. */
