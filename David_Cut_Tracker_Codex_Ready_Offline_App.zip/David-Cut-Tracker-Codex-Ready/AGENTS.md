# AGENTS.md — Instructions for Codex

You are working on David's college weight-loss, meal-prep, budget, and lifting tracker.

Goals:
1. Make the tracker feel like a polished free app.
2. Keep setup easy: no paid software, no server, no database required for basic use.
3. Preserve the no-tuna rule everywhere.
4. Keep food near $200/month.
5. Support college-student 1-2 meal/day workflows.
6. Use cheap, bulk, freezer-friendly meals and vacuum-sealer inventory.
7. Make cheat-meal eligibility calculated from calories, lifting, steps, protein, and last cheat day.

User context:
- Current weight around 260 lb.
- Waist around 38 inches.
- Goal is a slow 2-year cut while lifting.
- Owns Ninja Creami, rice cooker, food scale, knives, steel pan, and vacuum sealer.
- No tuna.

Definition of done:
- Daily meal logging calculates calories/protein/cost.
- Cheat engine returns clear status.
- Grocery cart updates total when an item is not bought.
- Freezer inventory handles vacuum-sealed packs.
- Dashboard is clean and easy.
- No tuna appears anywhere.
