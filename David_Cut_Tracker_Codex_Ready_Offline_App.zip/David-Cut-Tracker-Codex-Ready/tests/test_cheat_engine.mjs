import assert from 'node:assert/strict';
import fs from 'node:fs';

function statusFor({calorie_bank, lift_days, step_days, days_since_cheat, protein_avg}) {
  if (calorie_bank >= 4000 && lift_days >= 3 && step_days >= 5 && days_since_cheat >= 10 && protein_avg >= 160) return 'Maintenance/refeed day allowed';
  if (calorie_bank >= 2200 && lift_days >= 3 && step_days >= 4 && days_since_cheat >= 7 && protein_avg >= 160) return 'Controlled cheat meal allowed';
  if (calorie_bank >= 1500 && lift_days >= 2 && step_days >= 3) return 'Almost earned';
  return 'Not earned';
}
const csv = fs.readFileSync(new URL('./cheat_day_test_cases.csv', import.meta.url), 'utf8').trim().split('\n');
const headers = csv[0].split(',').map(h => h.trim());
for (const line of csv.slice(1)) {
  const cells = line.split(',').map(c => c.trim());
  const row = Object.fromEntries(headers.map((h, i) => [h, cells[i]]));
  const got = statusFor({
    calorie_bank: Number(row.calorie_bank),
    lift_days: Number(row.lift_days),
    step_days: Number(row.step_days),
    days_since_cheat: Number(row.days_since_cheat),
    protein_avg: Number(row.protein_avg)
  });
  assert.equal(got, row.expected, row.case);
}
console.log('All cheat engine test cases passed.');
