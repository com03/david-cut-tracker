
const $ = (id) => document.getElementById(id);
const money = (n) => `$${Number(n || 0).toFixed(2)}`;
const num = (v) => Number(v || 0);
const todayISO = () => new Date().toISOString().slice(0,10);
const storeKey = 'davidCutTracker.v1';
let state = loadState();

function loadState(){
  const saved = localStorage.getItem(storeKey);
  if(saved){ try { return JSON.parse(saved); } catch(e) { console.warn(e); } }
  return {
    logs: [],
    groceries: APP_DATA.GROCERIES.map((g, i) => ({id: i, buy: g.buy !== 'No', actualPrice: g.target_price_usd})),
    freezer: [],
    settings: APP_DATA.SETTINGS
  };
}
function saveState(){ localStorage.setItem(storeKey, JSON.stringify(state)); }

function init(){
  $('logDate').value = todayISO(); $('freezerDate').value = todayISO();
  populateMealSelects(); renderAll();
  document.querySelectorAll('input,select').forEach(el => el.addEventListener('change', updateMealPreview));
  $('saveDayBtn').addEventListener('click', saveDay);
  $('clearFormBtn').addEventListener('click', clearForm);
  $('mealSearch').addEventListener('input', renderMealTable);
  $('addFreezerBtn').addEventListener('click', addFreezerItem);
  $('exportJsonBtn').addEventListener('click', exportJson);
  $('exportCsvBtn').addEventListener('click', exportDailyCsv);
  $('importJsonInput').addEventListener('change', importJson);
}
function populateMealSelects(){
  const opts = ['<option value="">None</option>'].concat(APP_DATA.MEALS.map(m => `<option value="${m.meal_id}">${m.name} — ${m.calories} cal / ${m.protein_g}g</option>`)).join('');
  document.querySelectorAll('.mealSelect').forEach(s => s.innerHTML = opts);
}
function getMeal(id){ return APP_DATA.MEALS.find(m => m.meal_id === id); }
function selectedMeals(){ return ['meal1','meal2','meal3'].map(id => getMeal($(id).value)).filter(Boolean); }
function dayTotals(){
  const meals = selectedMeals();
  return {
    calories: meals.reduce((a,m)=>a+num(m.calories),0) + num($('customCals').value),
    protein: meals.reduce((a,m)=>a+num(m.protein_g),0) + num($('customProtein').value),
    cost: meals.reduce((a,m)=>a+num(m.cost_usd),0) + num($('customCost').value),
    mealNames: meals.map(m=>m.name)
  };
}
function updateMealPreview(){
  const t = dayTotals();
  $('mealPreview').innerHTML = `<strong>Today preview:</strong> ${Math.round(t.calories)} calories • ${Math.round(t.protein)}g protein • ${money(t.cost)}<br><span class="small">Meals: ${t.mealNames.join(' + ') || 'none selected yet'}</span>`;
}
function saveDay(){
  const t = dayTotals();
  const entry = {
    date: $('logDate').value || todayISO(), weight: num($('weight').value), waist: num($('waist').value), sleep: num($('sleep').value),
    steps: num($('steps').value), lifted: $('lifted').value, cardio: num($('cardio').value), cheat: $('cheat').value,
    mealIds: ['meal1','meal2','meal3'].map(id => $(id).value).filter(Boolean), mealNames: t.mealNames,
    calories: Math.round(t.calories), protein: Math.round(t.protein), cost: Number(t.cost.toFixed(2))
  };
  state.logs = state.logs.filter(l => l.date !== entry.date);
  state.logs.push(entry); state.logs.sort((a,b)=> a.date.localeCompare(b.date));
  saveState(); renderAll(); $('todayStatus').textContent = 'Saved';
}
function clearForm(){
  ['weight','waist','sleep','steps','cardio','customCals','customProtein','customCost'].forEach(id => $(id).value = id.startsWith('custom') ? 0 : '');
  ['meal1','meal2','meal3'].forEach(id => $(id).value = '');
  $('lifted').value = 'Yes'; $('cheat').value = 'No'; $('todayStatus').textContent = 'Ready'; updateMealPreview();
}
function lastNDays(n){
  const now = new Date(todayISO()); const start = new Date(now); start.setDate(now.getDate() - (n-1));
  return state.logs.filter(l => new Date(l.date) >= start && new Date(l.date) <= now);
}
function computeCheat(){
  const s = state.settings, logs = lastNDays(7), target = s.default_daily_calorie_target || 2500;
  const consumed = logs.reduce((a,l)=>a+num(l.calories),0), bank = target * 7 - consumed;
  const liftDays = logs.filter(l => l.lifted === 'Yes').length, stepDays = logs.filter(l => num(l.steps) >= (s.step_goal || 8500)).length;
  const proteinAvg = logs.length ? logs.reduce((a,l)=>a+num(l.protein),0)/logs.length : 0;
  const cheatLogs = state.logs.filter(l => l.cheat === 'Yes').sort((a,b)=>b.date.localeCompare(a.date));
  const daysSinceCheat = cheatLogs[0] ? Math.floor((new Date(todayISO()) - new Date(cheatLogs[0].date))/(1000*60*60*24)) : 999;
  let status = 'Not earned', cls = 'status-bad', cap = 0, why = [];
  if (bank >= 4000 && liftDays >= 3 && stepDays >= 5 && daysSinceCheat >= 10 && proteinAvg >= 160) {
    status = 'Maintenance/refeed day allowed'; cls = 'status-good'; cap = target + Math.min(700, bank - 2500);
  } else if (bank >= 2200 && liftDays >= 3 && stepDays >= 4 && daysSinceCheat >= 7 && proteinAvg >= 160) {
    status = 'Controlled cheat meal allowed'; cls = 'status-good'; cap = Math.min(1000, bank - 1000);
  } else if (bank >= 1500 && liftDays >= 2 && stepDays >= 3) {
    status = 'Almost earned'; cls = 'status-warn';
  }
  if(bank < 2200) why.push(`Need more calorie bank: ${Math.round(bank)}/2200`);
  if(liftDays < 3) why.push(`Lift days: ${liftDays}/3`);
  if(stepDays < 4) why.push(`Step-goal days: ${stepDays}/4`);
  if(proteinAvg < 160) why.push(`Protein avg: ${Math.round(proteinAvg)}/160g`);
  if(daysSinceCheat < 7) why.push(`Days since last cheat: ${daysSinceCheat}/7`);
  return {status, cls, cap: Math.max(0, Math.round(cap)), bank, consumed, liftDays, stepDays, proteinAvg, daysSinceCheat, logsCount: logs.length, why};
}
function renderDashboard(){
  const logs = state.logs, last = logs[logs.length-1] || {}, cheat = computeCheat(), groceryTotal = groceryTotalCost();
  const cards = [
    ['Current Weight', last.weight ? `${last.weight} lb` : '—', 'latest saved weight'],
    ['Current Waist', last.waist ? `${last.waist} in` : '—', 'latest saved waist'],
    ['7-Day Bank', `${Math.round(cheat.bank)} cal`, 'positive bank = room earned'],
    ['Cheat Status', cheat.status, `${cheat.cap ? 'Cap: ' + cheat.cap + ' cal' : 'earn it with consistency'}`],
    ['Protein Avg', `${Math.round(cheat.proteinAvg)}g`, 'last 7 logged days'],
    ['Lift Days', `${cheat.liftDays}/4`, 'last 7 days'],
    ['Step Days', `${cheat.stepDays}/5`, 'last 7 days'],
    ['Monthly Cart', money(groceryTotal), 'target $200/month']
  ];
  $('dashboardCards').innerHTML = cards.map(c => `<div class="card"><div class="label">${c[0]}</div><div class="value">${c[1]}</div><div class="sub">${c[2]}</div></div>`).join('');
}
function renderCheat(){
  const c = computeCheat(); const pct = (v,max) => Math.min(100, Math.max(0, (v/max)*100));
  $('cheatEngine').innerHTML = `<h3 class="${c.cls}">${c.status}</h3><p>${c.cap ? `Allowed cap: <strong>${c.cap} calories</strong>. Keep it controlled, protein first, log it.` : 'No uncontrolled cheat yet. Build the bank first.'}</p>
  <div>Calorie bank: ${Math.round(c.bank)} / 2200</div><div class="progress"><span style="width:${pct(c.bank,2200)}%"></span></div>
  <div>Lifts: ${c.liftDays} / 3</div><div class="progress"><span style="width:${pct(c.liftDays,3)}%"></span></div>
  <div>Step days: ${c.stepDays} / 4</div><div class="progress"><span style="width:${pct(c.stepDays,4)}%"></span></div>
  <div>Protein avg: ${Math.round(c.proteinAvg)} / 160g</div><div class="progress"><span style="width:${pct(c.proteinAvg,160)}%"></span></div>
  <p class="small">${c.why.length ? 'Blocks: ' + c.why.join(' • ') : 'All controlled-cheat requirements are met.'}</p>`;
}
function groceryTotalCost(){ return state.groceries.reduce((a,g)=> a + (g.buy ? num(g.actualPrice) : 0), 0); }
function renderGroceryList(){
  $('groceryList').innerHTML = `<div class="grocery-row"><strong></strong><strong>Item</strong><strong>Price</strong><strong>Category</strong></div>` + APP_DATA.GROCERIES.map((g,i)=>{
    const st = state.groceries[i] || {buy:true, actualPrice:g.target_price_usd};
    return `<div class="grocery-row"><input type="checkbox" ${st.buy?'checked':''} onchange="toggleGrocery(${i}, this.checked)"><div><strong>${g.item}</strong><div class="small">${g.supports_meals}</div></div><input type="number" step="0.01" value="${st.actualPrice}" onchange="setGroceryPrice(${i}, this.value)"><span class="tag">${g.category}</span></div>`;
  }).join('') + `<p><strong>Total monthly cart:</strong> ${money(groceryTotalCost())} <span class="small">(${groceryTotalCost() > 200 ? 'over budget' : 'within target'})</span></p>`;
}
window.toggleGrocery = (i, checked) => { state.groceries[i].buy = checked; saveState(); renderAll(); };
window.setGroceryPrice = (i, value) => { state.groceries[i].actualPrice = num(value); saveState(); renderAll(); };
function renderMealTable(){
  const q = ($('mealSearch').value || '').toLowerCase();
  const rows = APP_DATA.MEALS.filter(m => [m.name,m.category,m.ingredients,m.aliases].join(' ').toLowerCase().includes(q));
  $('mealTable').innerHTML = `<table><thead><tr><th>Meal</th><th>Cal</th><th>Protein</th><th>Cost</th><th>Notes</th></tr></thead><tbody>` + rows.map(m => `<tr><td><strong>${m.name}</strong><br><span class="tag">${m.category}</span> <span class="small">${m.freezer_friendly === 'Yes' ? 'freezer-friendly' : ''}</span></td><td>${m.calories}</td><td>${m.protein_g}g</td><td>${money(m.cost_usd)}</td><td>${m.instructions}<br><span class="small">${m.ingredients}</span></td></tr>`).join('') + `</tbody></table>`;
}
function addFreezerItem(){
  const packed = $('freezerDate').value || todayISO(); const d = new Date(packed); d.setDate(d.getDate() + 120);
  state.freezer.push({item: $('freezerItem').value || 'Vacuum sealed pack', servings: num($('freezerServings').value), calories: num($('freezerCals').value), protein: num($('freezerProtein').value), packed, useBy: d.toISOString().slice(0,10)});
  saveState(); renderFreezer();
}
function renderFreezer(){
  $('freezerTable').innerHTML = `<table><thead><tr><th>Item</th><th>Servings</th><th>Cal</th><th>Protein</th><th>Packed</th><th>Use By</th></tr></thead><tbody>` + state.freezer.map(f=>`<tr><td>${f.item}</td><td>${f.servings}</td><td>${f.calories}</td><td>${f.protein}g</td><td>${f.packed}</td><td>${f.useBy}</td></tr>`).join('') + `</tbody></table>`;
}
function renderHistory(){
  const rows = [...state.logs].reverse();
  $('historyTable').innerHTML = `<table><thead><tr><th>Date</th><th>Weight</th><th>Waist</th><th>Calories</th><th>Protein</th><th>Steps</th><th>Lifted</th><th>Cheat</th><th>Meals</th></tr></thead><tbody>` + rows.map(l => `<tr><td>${l.date}</td><td>${l.weight||''}</td><td>${l.waist||''}</td><td>${l.calories}</td><td>${l.protein}g</td><td>${l.steps}</td><td>${l.lifted}</td><td>${l.cheat}</td><td>${(l.mealNames||[]).join('<br>')}</td></tr>`).join('') + `</tbody></table>`;
}
function exportJson(){ download(`david-cut-tracker-backup-${todayISO()}.json`, JSON.stringify(state, null, 2), 'application/json'); }
function importJson(e){ const file = e.target.files[0]; if(!file) return; const reader = new FileReader(); reader.onload = () => { state = JSON.parse(reader.result); saveState(); renderAll(); }; reader.readAsText(file); }
function exportDailyCsv(){
  const headers = ['date','weight','waist','sleep','steps','lifted','cardio','cheat','calories','protein','cost','meals'];
  const lines = [headers.join(',')].concat(state.logs.map(l => headers.map(h => `"${String(h==='meals' ? (l.mealNames||[]).join(' | ') : (l[h] ?? '')).replaceAll('"','""')}"`).join(',')));
  download(`david-daily-log-${todayISO()}.csv`, lines.join('\n'), 'text/csv');
}
function download(name, content, type){ const a = document.createElement('a'); a.href = URL.createObjectURL(new Blob([content], {type})); a.download = name; a.click(); URL.revokeObjectURL(a.href); }
function renderAll(){ renderDashboard(); renderCheat(); renderGroceryList(); renderMealTable(); renderFreezer(); renderHistory(); updateMealPreview(); }
init();
