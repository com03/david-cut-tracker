# David Cut Tracker — Codex-Ready Project

This package is built so Codex can refine your tracker like a real project instead of trying to guess from one big spreadsheet.

## What is inside

- `current_workbook/David_Ultimate_Google_Sheets_Cut_Tracker_v7_NO_TUNA.xlsx` — your latest no-tuna spreadsheet.
- `web_app/` — a free offline browser app. Open `index.html`; no install needed.
- `data/` — clean CSV/JSON data for meals, groceries, workouts, settings, and cheat-day tests.
- `google_sheets/` — Apps Script starter code for Google Sheets menu/buttons.
- `docs/` — product spec and Codex prompt.
- `tests/` — cheat-engine test cases.

## Best free option

Use the offline web app first. It is easier than Google Sheets for daily logging because there are no formula errors, no paid software, and no setup beyond opening `web_app/index.html`.

## How to use

1. Unzip the package.
2. Open `web_app/index.html` in Chrome/Edge.
3. Log weight, waist, sleep, steps, lifted status, meals, and cheat meal status.
4. The dashboard calculates calories, protein, cost, weekly calorie bank, and cheat eligibility.
5. Use Export Backup weekly so you do not lose local browser data.

## How to use with Codex

Open this folder in VS Code or a terminal with Codex. Paste the prompt in `docs/codex_master_prompt.md`.

No tuna is allowed anywhere in user-facing meals, groceries, emergency foods, aliases, or meal plans.
