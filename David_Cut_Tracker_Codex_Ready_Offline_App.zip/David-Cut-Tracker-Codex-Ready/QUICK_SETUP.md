# Quick Setup

## Easiest: offline web app
1. Unzip this package.
2. Open `web_app/index.html` in Chrome/Edge.
3. Start logging.
4. Use Export Backup once per week.

## Spreadsheet backup
1. Upload `current_workbook/David_Ultimate_Google_Sheets_Cut_Tracker_v7_NO_TUNA.xlsx` to Google Drive.
2. Open with Google Sheets.
3. Paste `google_sheets/AppsScript_v7.gs` into Extensions > Apps Script if you want custom menu buttons.

## Codex
1. Open this unzipped folder in VS Code or terminal.
2. Run Codex in the folder.
3. Paste the prompt from `docs/codex_master_prompt.md`.
