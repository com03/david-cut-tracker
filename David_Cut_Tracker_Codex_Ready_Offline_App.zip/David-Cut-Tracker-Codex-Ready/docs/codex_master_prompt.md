You are improving David's free college cut tracker project.

Main task:
Make this into the smoothest possible free daily tracking app while preserving easy setup.

Requirements:
1. Keep the offline web app usable by opening `web_app/index.html` directly in a browser.
2. Keep Google Sheets workbook and Apps Script as optional backups.
3. Preserve the no-tuna rule across meals, groceries, recipes, suggestions, aliases, and sample plans.
4. Improve meal logging so selecting meals calculates calories, protein, cost, and today's totals.
5. Improve the Cheat Engine so it uses last-7-days calories, protein, lifting, step-goal days, and days since last cheat.
6. Grocery cart: if an item is marked not bought, total monthly/weekly cost changes immediately and affected meal categories are flagged.
7. Add freezer inventory support for vacuum-sealed packs, packed date, servings, calories/protein per serving, and use-by alerts.
8. Add visual polish: cards, progress bars, traffic-light statuses, daily streaks, budget meter, and clear mobile layout.
9. Add tests for the cheat engine using `tests/cheat_day_test_cases.csv`.
10. Keep export/import working so the user does not lose logs.
11. Do not add paid APIs or complicated setup.
12. If adding a framework, justify it and keep a no-build fallback.

Specific improvements:
- Searchable meal picker with aliases.
- One-click log common day templates.
- Encouraging "missed lift" reminders.
- "Closest cheap meals to hit remaining protein" suggestions.
- Meal-plan generator from remaining groceries.
- Inventory warning for expiring freezer packs.
- Budget warning above $200.
- Sleep warning if average sleep < 7 hours.

Run tests, fix bugs, and update README with exact setup instructions.
