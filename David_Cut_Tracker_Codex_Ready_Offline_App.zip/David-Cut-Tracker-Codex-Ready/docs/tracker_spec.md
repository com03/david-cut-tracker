# Tracker Product Spec

## Goal
Build a free daily tracker that combines meal logging, budget, lifting, steps, sleep, freezer inventory, and cheat-meal eligibility.

## Core flow
1. User enters weight, waist, sleep, steps, lifted status, cardio, and meals.
2. App calculates calories, protein, cost, and weekly calorie bank.
3. Cheat Engine decides if a controlled cheat meal is earned.
4. Grocery cart recalculates budget when items are marked not bought.
5. Freezer inventory tracks vacuum-sealed packs.

## Cheat Engine Rules
Controlled cheat allowed when:
- weekly calorie bank >= 2200
- lift days last 7 >= 3
- step-goal days last 7 >= 4
- days since last cheat >= 7
- average protein last 7 >= 160g

Maintenance/refeed day allowed when:
- weekly calorie bank >= 4000
- lift days last 7 >= 3
- step-goal days last 7 >= 5
- days since last cheat >= 10
- average protein last 7 >= 160g

No tuna.
