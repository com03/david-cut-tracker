# Sources and assumptions

- CDC weight loss: https://www.cdc.gov/healthy-weight-growth/losing-weight/index.html
- CDC adult physical activity: https://www.cdc.gov/physical-activity-basics/guidelines/adults.html
- NIH sleep deprivation: https://www.nhlbi.nih.gov/health/sleep-deprivation
- FoodSafety.gov minimum temperatures: https://www.foodsafety.gov/food-safety-charts/safe-minimum-internal-temperatures
- FoodSafety.gov cold storage: https://www.foodsafety.gov/food-safety-charts/cold-food-storage-charts
- ISSN protein position stand: https://pmc.ncbi.nlm.nih.gov/articles/PMC5477153/

Nutrition and prices are estimates. Update actual prices when shopping.
